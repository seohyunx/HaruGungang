import React from 'react'

const NutritionInfo = () => {
  return (
    <div>NutritionInfo</div>
  )
}

export default NutritionInfo