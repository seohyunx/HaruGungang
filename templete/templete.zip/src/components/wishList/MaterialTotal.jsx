import React from 'react'
import RecAmountNutri from './RecAmountNutri'

const MaterialTotal = () => {
  return (
    <div>
      <RecAmountNutri/>
    </div>
  )
}

export default MaterialTotal